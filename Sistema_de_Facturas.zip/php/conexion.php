<?php
	

	$servidor="sql312.epizy.com";
	$usuario="epiz_25875687";
	$password="CVXaF9qeIRFWj5B";
	$BD="epiz_25875687_facturasmiscelanea";

	$conexion=@mysqli_connect($servidor,$usuario,$password,$BD);
	

?>